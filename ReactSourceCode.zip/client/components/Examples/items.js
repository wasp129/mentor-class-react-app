const items = [
	{
		platform: "Facebook likes",
		value: 13.84,
		interval: 100
	},
	{
		platform: "Messenger beskeder",
		value: 6.45,
		interval: 100
	},
	{
		platform: "Tweets",
		value: 14.45,
		interval: 100
	},
	{
		platform: "Billeder uploadet",
		value: 1.54,
		interval: 100
	},
	{
		platform: "Google søgninger",
		value: 121.8,
		interval: 100
	},
	{
		platform: "Video views",
		value: 109,
		interval: 100
	},
	{
		platform: "Snaps",
		value: 81.17,
		interval: 100
	},
	{
		platform: "Penge brugt online",
		value: 3170.98,
		interval: 100
	},
	{
		platform: "Spotify brug",
		value: 25.44,
		interval: 100
	},
	{
		platform: "Emails sendt",
		value: 405.37,
		interval: 100
	},
	{
		platform: "Penge overført gennem mobilepay",
		value: 1364,
		interval: 100
	},
	{
		platform: "Smartphone unlocks",
		value: 4.4,
		interval: 500
	}
]

export default items;